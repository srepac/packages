#!/bin/bash
# In order to make this work on pi-kvm, you will need to install some missing
# ... dependencies as per below:
rw
pacman -S python-pip
pip3 install smbus
systemctl enable --now fan-control.service
ro
